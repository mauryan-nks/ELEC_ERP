<?php

namespace App\Services;

use RuntimeException;

class WhatsAppQueueService
{
    public function processPending(
        int $limit=25
    ): int
    {
        $db=db_connect();

        $bridge=new WhatsAppBridge();

        $rows=$db->table('whatsapp_queue')
            ->where('status','queued')
            ->where(
                'scheduled_at <=',
                date('Y-m-d H:i:s')
            )
            ->where('attempts <',3)
            ->orderBy(
                'scheduled_at',
                'ASC'
            )
            ->limit($limit)
            ->get()
            ->getResultArray();

        $sent=0;

        foreach($rows as $row){

            $now=date(
                'Y-m-d H:i:s'
            );

            $attempt=(int)$row['attempts']+1;

            $ok=$db->table('whatsapp_queue')
                ->where([
                    'id'=>$row['id'],
                    'status'=>'queued'
                ])
                ->update([
                    'status'=>'processing',
                    'attempts'=>$attempt,
                    'updated_at'=>$now
                ]);

            if(!$ok){
                continue;
            }

            try{

                /*
                 * MEDIA
                 */
                if(
                    ($row['message_type']??'text')
                    ==='media'
                ){

                    $path=(string)(
                        $row['attachment_path']??''
                    );

                    if($path===''){
                        throw new RuntimeException(
                            'Queue item #'.$row['id'].
                            ' has no attachment_path.'
                        );
                    }

                    if(!is_file($path)){
                        throw new RuntimeException(
                            'Queue item #'.$row['id'].
                            ' attachment file does not exist: '.
                            $path
                        );
                    }

                    $bridge->sendMedia(
                        $row['phone'],
                        (string)(
                            $row['message']??''
                        ),
                        $path,
                        (string)(
                            $row['attachment_mime']
                            ??'application/pdf'
                        ),
                        (string)(
                            $row['attachment_name']
                            ??basename($path)
                        )
                    );

                }else{

                    /*
                     * TEXT
                     */
                    $bridge->send(
                        $row['phone'],
                        (string)(
                            $row['message']??''
                        )
                    );
                }

                /*
                 * SUCCESS
                 */
                $db->table('whatsapp_queue')
                    ->where(
                        'id',
                        $row['id']
                    )
                    ->update([
                        'status'=>'sent',
                        'sent_at'=>$now,
                        'last_error'=>null,
                        'updated_at'=>$now
                    ]);

                $sent++;

            }catch(\Throwable $e){

                /*
                 * FAILURE
                 */
                $db->table('whatsapp_queue')
                    ->where(
                        'id',
                        $row['id']
                    )
                    ->update([
                        'status'=>$attempt>=3
                            ? 'failed'
                            : 'queued',

                        'last_error'=>mb_substr(
                            $e->getMessage(),
                            0,
                            2000
                        ),

                        'updated_at'=>date(
                            'Y-m-d H:i:s'
                        )
                    ]);

                log_message(
                    'error',
                    'WhatsApp queue #{id} failed: {message}',
                    [
                        'id'=>$row['id'],
                        'message'=>$e->getMessage()
                    ]
                );
            }
        }

        return $sent;
    }
}
