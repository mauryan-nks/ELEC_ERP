<?php

namespace App\Services;

use RuntimeException;

class WhatsAppBridge
{
    private string $baseUrl;
    private string $key;

    public function __construct()
    {
        $this->baseUrl=rtrim(
            (string)env(
                'WHATSAPP_BRIDGE_URL',
                'http://127.0.0.1:3099'
            ),
            '/'
        );

        $this->key=trim(
            (string)env(
                'whatsapp.bridgeKey',
                ''
            )
        );

        if($this->key===''){
            throw new RuntimeException(
                'WHATSAPP_BRIDGE_KEY is not configured.'
            );
        }
    }

    public function status(): array
    {
        return $this->request(
            'GET',
            '/status'
        );
    }

    public function send(
        string $phone,
        string $message
    ): array
    {
        return $this->request(
            'POST',
            '/send',
            [
                'phone'=>$phone,
                'message'=>$message,
            ]
        );
    }

    public function sendMedia(
        string $phone,
        string $message,
        string $path,
        string $mimetype='application/pdf',
        string $filename='document.pdf'
    ): array
    {
        if(!is_file($path)){
            throw new RuntimeException(
                'Media file does not exist: '.$path
            );
        }

        $data=file_get_contents($path);

        if($data===false){
            throw new RuntimeException(
                'Unable to read media file: '.$path
            );
        }

        return $this->sendMediaData(
            $phone,
            $message,
            base64_encode($data),
            $mimetype,
            $filename
        );
    }

    public function sendMediaData(
        string $phone,
        string $message,
        string $base64Data,
        string $mimetype,
        string $filename
    ): array
    {
        if($base64Data===''){
            throw new RuntimeException(
                'Media data is empty.'
            );
        }

        return $this->request(
            'POST',
            '/send',
            [
                'phone'=>$phone,
                'message'=>$message,

                'media'=>[
                    'data'=>$base64Data,
                    'mimetype'=>$mimetype,
                    'filename'=>$filename,
                ],
            ]
        );
    }

    /*
     * Optional endpoint.
     *
     * This is NOT required by SaleService anymore because
     * SaleService can generate the PDF directly with Chromium.
     */
    public function htmlToPdf(
        string $html
    ): array
    {
        if(trim($html)===''){
            throw new RuntimeException(
                'Cannot convert empty HTML to PDF.'
            );
        }

        return $this->request(
            'POST',
            '/html-to-pdf',
            [
                'html'=>$html,
            ],
            120
        );
    }

    private function request(
        string $method,
        string $path,
        ?array $payload=null,
        int $timeout=30
    ): array
    {
        $url=$this->baseUrl.$path;

        $ch=curl_init($url);

        if($ch===false){
            throw new RuntimeException(
                'Unable to initialize cURL.'
            );
        }

        $headers=[
            'Accept: application/json',
            'X-Bridge-Key: '.$this->key,
        ];

        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_FOLLOWLOCATION=>false,
            CURLOPT_CONNECTTIMEOUT=>10,
            CURLOPT_TIMEOUT=>$timeout,
            CURLOPT_HTTPHEADER=>$headers,
            CURLOPT_CUSTOMREQUEST=>strtoupper($method),
        ]);

        if($payload!==null){

            $json=json_encode(
                $payload,
                JSON_UNESCAPED_SLASHES|
                JSON_UNESCAPED_UNICODE
            );

            if($json===false){

                curl_close($ch);

                throw new RuntimeException(
                    'Unable to encode bridge request.'
                );
            }

            curl_setopt(
                $ch,
                CURLOPT_POSTFIELDS,
                $json
            );

            $headers[]=
                'Content-Type: application/json';

            curl_setopt(
                $ch,
                CURLOPT_HTTPHEADER,
                $headers
            );
        }

        $response=curl_exec($ch);

        if($response===false){

            $error=curl_error($ch);

            curl_close($ch);

            throw new RuntimeException(
                'WhatsApp bridge connection failed: '.
                $error
            );
        }

        $httpCode=(int)curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        );

        curl_close($ch);

        $decoded=json_decode(
            $response,
            true
        );

        if(!is_array($decoded)){

            throw new RuntimeException(
                'Invalid response from WhatsApp bridge. HTTP '.
                $httpCode.
                ': '.
                mb_substr(
                    $response,
                    0,
                    1000
                )
            );
        }

        if(
            $httpCode<200 ||
            $httpCode>=300 ||
            empty($decoded['ok'])
        ){

            throw new RuntimeException(
                (string)(
                    $decoded['error']
                    ??
                    'WhatsApp bridge returned HTTP '.
                    $httpCode
                )
            );
        }

        return $decoded;
    }
}
