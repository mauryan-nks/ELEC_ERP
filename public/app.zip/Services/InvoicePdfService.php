<?php

namespace App\Services;

use RuntimeException;

class InvoicePdfService
{
    public function getInvoiceData(int $saleId): array
    {
        $db = db_connect();

        $sale = $db->table('sales s')
            ->select(
                's.*,
                c.name customer_name,
                c.phone customer_phone,
                c.email customer_email,
                c.address customer_address,
                c.gstin customer_gstin'
            )
            ->join(
                'customers c',
                'c.id=s.customer_id'
            )
            ->where('s.id', $saleId)
            ->get()
            ->getRowArray();

        if (!$sale) {
            throw new RuntimeException(
                'Sale #' . $saleId . ' not found.'
            );
        }

        $items = $db->table('sale_items si')
            ->select(
                'si.id,
                 si.qty,
                 si.unit_price,
                 si.discount_amount,
                 si.tax_percent,
                 si.line_total,
                 p.name,
                 p.model,
                 p.hsn_sac,
                 u.imei1,
                 u.imei2,
                 u.serial_no,
                 u.unique_id'
            )
            ->join(
                'products p',
                'p.id=si.product_id'
            )
            ->join(
                'inventory_units u',
                'u.id=si.inventory_unit_id',
                'left'
            )
            ->where('si.sale_id', $saleId)
            ->orderBy('si.id')
            ->get()
            ->getResultArray();

        $currentShop = $db->table('shop_settings')
            ->where('id', 1)
            ->get()
            ->getRowArray() ?? [];

        $shop = $currentShop;

        if (!empty($sale['company_snapshot_json'])) {

            $snapshot = json_decode(
                (string) $sale['company_snapshot_json'],
                true
            );

            if (is_array($snapshot)) {
                $shop = array_replace(
                    $currentShop,
                    $snapshot
                );
            }
        }

        $invoiceConfig = [];

        if (!empty($sale['invoice_config_json'])) {

            $decoded = json_decode(
                (string) $sale['invoice_config_json'],
                true
            );

            if (is_array($decoded)) {
                $invoiceConfig = $decoded;
            }
        }

        $invoiceConfig = array_replace(
            [
                'template' =>
                    $shop['invoice_template'] ??
                    'classic',

                'title' =>
                    $shop['invoice_title'] ??
                    'TAX INVOICE',

                'gst_enabled' =>
                    (bool) (
                        $shop['invoice_default_gst_enabled'] ??
                        1
                    ),

                'gst_mode' =>
                    $shop['invoice_default_gst_mode'] ??
                    'inclusive',

                'show_logo' =>
                    (bool) (
                        $shop['invoice_show_logo'] ??
                        1
                    ),

                'show_signature' =>
                    (bool) (
                        $shop['invoice_show_signature'] ??
                        1
                    ),

                'show_company_phone' =>
                    (bool) (
                        $shop['invoice_show_company_phone'] ??
                        1
                    ),

                'show_company_email' =>
                    (bool) (
                        $shop['invoice_show_company_email'] ??
                        1
                    ),

                'show_company_address' =>
                    (bool) (
                        $shop['invoice_show_company_address'] ??
                        1
                    ),

                'show_customer_address' =>
                    (bool) (
                        $shop['invoice_show_customer_address'] ??
                        1
                    ),

                'show_customer_gstin' =>
                    (bool) (
                        $shop['invoice_show_customer_gstin'] ??
                        1
                    ),

                'show_imei' =>
                    (bool) (
                        $shop['invoice_show_imei'] ??
                        1
                    ),

                'show_hsn' =>
                    (bool) (
                        $shop['invoice_show_hsn'] ??
                        1
                    ),

                'show_item_discount' =>
                    (bool) (
                        $shop['invoice_show_item_discount'] ??
                        1
                    ),

                'customer_address_position' =>
                    $shop['customer_address_position'] ??
                    'left',

                'terms' =>
                    $shop['invoice_terms'] ??
                    null,

                'footer' =>
                    $shop['invoice_footer'] ??
                    null,

                'invoice_color' =>
                    $shop['invoice_color'] ??
                    '#e87523',
            ],
            $invoiceConfig
        );

        $payments = $db->table('payments')
            ->where('sale_id', $saleId)
            ->orderBy('paid_at', 'ASC')
            ->get()
            ->getResultArray();

        return [
            'title'         => 'Invoice ' . $sale['invoice_no'],
            'sale'          => $sale,
            'items'         => $items,
            'shop'          => $shop,
            'payments'      => $payments,
            'invoiceConfig' => $invoiceConfig,

            /*
             * The PDF view currently uses $cfg.
             * Provide it explicitly as well.
             */
            'cfg'            => $invoiceConfig,
        ];
    }
}