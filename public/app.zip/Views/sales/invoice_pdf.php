<?php
/**
 * Standalone invoice HTML used for Chromium PDF generation.
 *
 * IMPORTANT:
 * This file must NOT extend layouts/main.
 * It must contain complete HTML because Chromium receives
 * this HTML directly through the local WhatsApp bridge.
 */

$cfg = $invoiceConfig ?? [];

$gstEnabled = (bool) (
    $cfg['gst_enabled'] ?? false
);

$gstMode = $cfg['gst_mode'] ?? 'inclusive';

$color = preg_match(
    '/^#[0-9a-fA-F]{6}$/',
    (string) (
        $cfg['invoice_color']
        ?? '#e87523'
    )
)
    ? (
        $cfg['invoice_color']
        ?? '#e87523'
    )
    : '#e87523';

$currency =
    $shop['currency']
    ?? 'INR';

$money =
    $currency === 'INR'
        ? '₹'
        : $currency . ' ';

$img = static function (
    $base64,
    $mime
) {
    if (!$base64) {
        return null;
    }

    return 'data:' .
        ($mime ?: 'image/png') .
        ';base64,' .
        $base64;
};

$logo = $img(
    $shop['logo_base64'] ?? null,
    $shop['logo_mime'] ?? null
);

$signature = $img(
    $shop['signature_base64'] ?? null,
    $shop['signature_mime'] ?? null
);

$showCompanyPhone =
    !empty($cfg['show_company_phone']);

$showCompanyEmail =
    !empty($cfg['show_company_email']);

$showCompanyAddress =
    !empty($cfg['show_company_address']);

$showCustomerAddress =
    !empty($cfg['show_customer_address']);

$showCustomerGstin =
    $gstEnabled &&
    !empty($cfg['show_customer_gstin']);

$showImei =
    !empty($cfg['show_imei']);

$showHsn =
    !empty($cfg['show_hsn']);

$showItemDiscount =
    !empty($cfg['show_item_discount']);

$showSignature =
    !empty($cfg['show_signature']) &&
    !empty($signature);

$lineDiscount =
    (float) (
        $sale['line_discount_total']
        ?? $sale['discount_total']
        ?? 0
    );

$overallDiscount =
    (float) (
        $sale['overall_discount_amount']
        ?? 0
    );
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">

<title>
    <?= esc(
        $sale['invoice_no'] ?? 'Invoice'
    ) ?>
</title>

<style>

@page {
    size: A4;
    margin: 12mm 12mm 15mm 12mm;
}

* {
    box-sizing: border-box;
}

html,
body {
    margin: 0;
    padding: 0;
}

body {
    font-family:
        "DejaVu Sans",
        Arial,
        sans-serif;

    color: #18202a;
    background: #ffffff;

    font-size: 10px;
    line-height: 1.45;
}

.invoice {
    width: 100%;

    border: 1px solid #d9dde2;

    padding: 20px;

    --accent: <?= esc($color) ?>;
}

.head {
    display: table;
    width: 100%;

    border-bottom:
        2px solid var(--accent);

    padding-bottom: 14px;

    margin-bottom: 15px;
}

.company {
    display: table-cell;

    width: 65%;

    vertical-align: top;
}

.logo {
    width: 58px;
    height: 58px;

    object-fit: contain;

    float: left;

    margin-right: 12px;
}

.company h1 {
    margin: 0 0 5px;

    font-size: 20px;

    line-height: 1.2;
}

.company-info {
    color: #68717b;

    font-size: 9px;
}

.doc {
    display: table-cell;

    width: 35%;

    text-align: right;

    vertical-align: top;
}

.title {
    color: var(--accent);

    font-size: 18px;

    font-weight: bold;

    margin-bottom: 3px;
}

.invoice-number {
    font-size: 12px;

    font-weight: bold;

    margin-bottom: 5px;
}

.party {
    margin: 15px 0;

    padding: 11px;

    border:
        1px solid #ddd;

    background:
        #f7f8fa;
}

.label {
    color: var(--accent);

    font-size: 8px;

    font-weight: bold;

    text-transform: uppercase;

    letter-spacing: .3px;
}

.party strong {
    font-size: 11px;
}

.party address {
    margin-top: 4px;

    white-space: normal;
}

.muted {
    color: #68717b;
}

.table {
    width: 100%;

    border-collapse: collapse;

    table-layout: fixed;
}

.table th,
.table td {
    border-bottom:
        1px solid #ddd;

    padding: 7px;

    vertical-align: top;

    word-wrap: break-word;
}

.table th {
    background:
        #f3f4f6;

    text-align: left;

    font-size: 8px;
}

.table td {
    font-size: 9px;
}

.table th:first-child,
.table td:first-child {
    width: 5%;
}

.table th:nth-child(2),
.table td:nth-child(2) {
    width: 35%;
}

.num {
    text-align: right;

    white-space: nowrap;
}

.item-sub {
    display: block;

    color: #68717b;

    font-size: 8px;

    margin-top: 2px;
}

.bottom {
    margin-top: 18px;

    display: table;

    width: 100%;
}

.terms {
    display: table-cell;

    width: 58%;

    vertical-align: top;

    padding-right: 15px;
}

.terms p {
    margin-top: 5px;

    white-space: normal;
}

.totals {
    display: table-cell;

    width: 42%;

    vertical-align: top;
}

.totals-row {
    display: table;

    width: 100%;

    padding: 4px 0;
}

.totals-row span {
    display: table-cell;

    width: 60%;
}

.totals-row strong {
    display: table-cell;

    width: 40%;

    text-align: right;
}

.grand {
    border-top:
        2px solid #18202a;

    padding-top: 7px;

    margin-top: 3px;

    font-size: 13px;

    font-weight: bold;
}

.due {
    font-weight: bold;

    color: var(--accent);
}

.footer {
    margin-top: 25px;

    border-top:
        1px solid #ddd;

    padding-top: 12px;

    display: table;

    width: 100%;
}

.footer-message {
    display: table-cell;

    vertical-align: bottom;

    width: 65%;
}

.sign {
    display: table-cell;

    text-align: right;

    vertical-align: bottom;

    width: 35%;
}

.sign img {
    max-width: 120px;

    max-height: 50px;

    object-fit: contain;
}

.no-break {
    page-break-inside: avoid;
}

@media print {

    body {
        background: #fff;
    }

    .invoice {
        border: 1px solid #d9dde2;
    }
}

</style>
</head>

<body>

<div class="invoice">

    <!-- HEADER -->

    <div class="head">

        <div class="company">

            <?php if ($logo): ?>

                <img
                    class="logo"
                    src="<?= $logo ?>"
                    alt="Company logo"
                >

            <?php endif; ?>

            <h1>
                <?= esc(
                    $shop['name']
                    ?? 'Shop'
                ) ?>
            </h1>

            <div class="company-info">

                <?php if (
                    $showCompanyAddress &&
                    !empty($shop['address'])
                ): ?>

                    <?= nl2br(
                        esc($shop['address'])
                    ) ?>

                    <br>

                <?php endif; ?>

                <?php if (
                    $showCompanyPhone &&
                    !empty($shop['phone'])
                ): ?>

                    <?= esc(
                        $shop['phone']
                    ) ?>

                <?php endif; ?>

                <?php if (
                    $showCompanyEmail &&
                    !empty($shop['email'])
                ): ?>

                    <?php if (
                        $showCompanyPhone &&
                        !empty($shop['phone'])
                    ): ?>
                        ·
                    <?php endif; ?>

                    <?= esc(
                        $shop['email']
                    ) ?>

                <?php endif; ?>

                <?php if (
                    $gstEnabled &&
                    !empty($shop['gstin'])
                ): ?>

                    <br>
                    GSTIN:
                    <?= esc(
                        $shop['gstin']
                    ) ?>

                <?php endif; ?>

            </div>

        </div>

        <div class="doc">

            <div class="title">
                <?= esc(
                    $cfg['title']
                    ?? 'INVOICE'
                ) ?>
            </div>

            <div class="invoice-number">
                <?= esc(
                    $sale['invoice_no']
                ) ?>
            </div>

            Date:
            <?= esc(
                date(
                    'd M Y',
                    strtotime(
                        $sale['sale_date']
                    )
                )
            ) ?>

            <?php if (
                !empty($sale['due_date'])
            ): ?>

                <br>

                Due:
                <?= esc(
                    date(
                        'd M Y',
                        strtotime(
                            $sale['due_date']
                        )
                    )
                ) ?>

            <?php endif; ?>

            <br>

            Status:
            <?= esc(
                ucfirst(
                    $sale['payment_status']
                    ?? ''
                )
            ) ?>

        </div>

    </div>


    <!-- CUSTOMER -->

    <div class="party no-break">

        <span class="label">
            Bill to
        </span>

        <br>

        <strong>
            <?= esc(
                $sale['customer_name']
                ?? ''
            ) ?>
        </strong>

        <?php if (
            !empty(
                $sale['customer_phone']
            )
        ): ?>

            <br>

            <?= esc(
                $sale['customer_phone']
            ) ?>

        <?php endif; ?>

        <?php if (
            !empty(
                $sale['customer_email']
            )
        ): ?>

            ·
            <?= esc(
                $sale['customer_email']
            ) ?>

        <?php endif; ?>

        <?php if (
            $showCustomerAddress &&
            !empty(
                $sale['customer_address']
            )
        ): ?>

            <br>

            <?= nl2br(
                esc(
                    $sale['customer_address']
                )
            ) ?>

        <?php endif; ?>

        <?php if (
            $showCustomerGstin &&
            !empty(
                $sale['customer_gstin']
            )
        ): ?>

            <br>

            GSTIN:
            <?= esc(
                $sale['customer_gstin']
            ) ?>

        <?php endif; ?>

    </div>


    <!-- ITEMS -->

    <table class="table">

        <thead>

        <tr>

            <th>
                #
            </th>

            <th>
                Item
            </th>

            <?php if ($showImei): ?>

                <th>
                    IMEI / Serial
                </th>

            <?php endif; ?>

            <th class="num">
                Qty
            </th>

            <th class="num">
                Rate
            </th>

            <?php if ($showItemDiscount): ?>

                <th class="num">
                    Discount
                </th>

            <?php endif; ?>

            <?php if ($gstEnabled): ?>

                <th class="num">
                    GST
                </th>

            <?php endif; ?>

            <th class="num">
                Amount
            </th>

        </tr>

        </thead>

        <tbody>

        <?php foreach (
            $items as $i => $it
        ): ?>

            <tr>

                <td>
                    <?= $i + 1 ?>
                </td>

                <td>

                    <strong>
                        <?= esc(
                            $it['name']
                        ) ?>
                    </strong>

                    <?php if (
                        !empty(
                            $it['model']
                        )
                    ): ?>

                        <span class="item-sub">
                            <?= esc(
                                $it['model']
                            ) ?>
                        </span>

                    <?php endif; ?>

                    <?php if (
                        $showHsn &&
                        !empty(
                            $it['hsn_sac']
                        )
                    ): ?>

                        <span class="item-sub">
                            HSN/SAC:
                            <?= esc(
                                $it['hsn_sac']
                            ) ?>
                        </span>

                    <?php endif; ?>

                </td>

                <?php if ($showImei): ?>

                    <td>

                        <?php

                        $ids = array_filter([
                            $it['imei1'] ?? null,
                            $it['imei2'] ?? null,
                            $it['serial_no'] ?? null,
                            $it['unique_id'] ?? null,
                        ]);

                        ?>

                        <?= $ids
                            ? esc(
                                implode(
                                    ' / ',
                                    $ids
                                )
                            )
                            : '—'
                        ?>

                    </td>

                <?php endif; ?>

                <td class="num">

                    <?= rtrim(
                        rtrim(
                            number_format(
                                (float)
                                $it['qty'],
                                3,
                                '.',
                                ''
                            ),
                            '0'
                        ),
                        '.'
                    ) ?>

                </td>

                <td class="num">

                    <?= $money ?>

                    <?= number_format(
                        (float)
                        $it['unit_price'],
                        2
                    ) ?>

                </td>

                <?php if (
                    $showItemDiscount
                ): ?>

                    <td class="num">

                        <?php if (
                            (float)
                            $it['discount_amount']
                            > 0
                        ): ?>

                            −

                        <?php endif; ?>

                        <?= $money ?>

                        <?= number_format(
                            (float)
                            $it['discount_amount'],
                            2
                        ) ?>

                    </td>

                <?php endif; ?>

                <?php if ($gstEnabled): ?>

                    <td class="num">

                        <?= number_format(
                            (float)
                            $it['tax_percent'],
                            2
                        ) ?>%

                    </td>

                <?php endif; ?>

                <td class="num">

                    <strong>

                        <?= $money ?>

                        <?= number_format(
                            (float)
                            $it['line_total'],
                            2
                        ) ?>

                    </strong>

                </td>

            </tr>

        <?php endforeach; ?>

        </tbody>

    </table>


    <!-- TOTALS -->

    <div class="bottom no-break">

        <div class="terms">

            <?php if (
                !empty(
                    $cfg['terms']
                )
            ): ?>

                <span class="label">
                    Terms & Conditions
                </span>

                <p>
                    <?= nl2br(
                        esc(
                            $cfg['terms']
                        )
                    ) ?>
                </p>

            <?php endif; ?>

        </div>


        <div class="totals">

            <div class="totals-row">

                <span>
                    Subtotal
                </span>

                <strong>
                    <?= $money ?>
                    <?= number_format(
                        (float)
                        $sale['subtotal'],
                        2
                    ) ?>
                </strong>

            </div>


            <?php if (
                $lineDiscount > 0
            ): ?>

                <div class="totals-row">

                    <span>
                        Line discounts
                    </span>

                    <strong>
                        −
                        <?= $money ?>
                        <?= number_format(
                            $lineDiscount,
                            2
                        ) ?>
                    </strong>

                </div>

            <?php endif; ?>


            <?php if (
                $overallDiscount > 0
            ): ?>

                <div class="totals-row">

                    <span>
                        Invoice discount
                    </span>

                    <strong>
                        −
                        <?= $money ?>
                        <?= number_format(
                            $overallDiscount,
                            2
                        ) ?>
                    </strong>

                </div>

            <?php endif; ?>


            <?php if (
                $gstEnabled
            ): ?>

                <div class="totals-row">

                    <span>
                        GST
                        <?php if (
                            $gstMode === 'inclusive'
                        ): ?>
                            (included)
                        <?php endif; ?>
                    </span>

                    <strong>
                        <?= $money ?>
                        <?= number_format(
                            (float)
                            $sale['tax_total'],
                            2
                        ) ?>
                    </strong>

                </div>

            <?php endif; ?>


            <div class="totals-row grand">

                <span>
                    Grand Total
                </span>

                <strong>
                    <?= $money ?>
                    <?= number_format(
                        (float)
                        $sale['grand_total'],
                        2
                    ) ?>
                </strong>

            </div>


            <div class="totals-row">

                <span>
                    Paid
                </span>

                <strong>
                    <?= $money ?>
                    <?= number_format(
                        (float)
                        $sale['paid_amount'],
                        2
                    ) ?>
                </strong>

            </div>


            <div class="totals-row due">

                <span>
                    Balance Due
                </span>

                <strong>
                    <?= $money ?>
                    <?= number_format(
                        (float)
                        $sale['due_amount'],
                        2
                    ) ?>
                </strong>

            </div>

        </div>

    </div>


    <!-- FOOTER -->

    <div class="footer no-break">

        <div class="footer-message">

            <?= esc(
                $cfg['footer']
                ?? 'Thank you for your business.'
            ) ?>

        </div>

        <?php if ($showSignature): ?>

            <div class="sign">

                <img
                    src="<?= $signature ?>"
                    alt="Authorized signature"
                >

                <br>

                Authorized Signatory

            </div>

        <?php endif; ?>

    </div>

</div>

</body>
</html>
